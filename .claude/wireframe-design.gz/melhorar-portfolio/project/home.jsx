// home.jsx — Home consolidada (decisões do usuário)
// Hero: estrutura da variação A, com placeholder de animação Lottie no lugar do H1
// Destaques: formato editorial da variação C (rows alternadas)
// Stack: marquee (default)
// Recomendações: pull-quote único da variação C

const LottieHero = () => (
  <div className="lottie-hero">
    <div className="lottie-hero__corners">
      <i /><i /><i /><i />
    </div>
    <div className="lottie-hero__inner">
      <div className="lottie-hero__icon">▶</div>
      <div className="lottie-hero__label">LOTTIE · Hero title animado</div>
      <div className="lottie-hero__sub">
        Mantém o asset atual do site<br/>
        (substituto do H1 estático)
      </div>
    </div>
  </div>
);

const HomeFinal = ({ onNav }) => (
  <>
    <Nav active="home" onNav={onNav} />
    <PageSummary>
      Hero <b style={{color:'var(--note)'}}>type-first</b> com a <b style={{color:'var(--note)'}}>animação Lottie</b> atual no lugar do H1 estático.
      Selos rotacionados para 9,56 e 4+ anos. Destaques em rows editoriais alternadas. Recomendação como pull-quote único.
    </PageSummary>

    {/* HERO */}
    <section style={{padding:'18px 0 40px', position:'relative'}}>
      <div className="flex gap-2 wrap" style={{marginBottom:18}}>
        <span className="status">Disponível p/ projetos</span>
      </div>

      <LottieHero />

      <div className="flex gap-3 wrap" style={{marginTop:22, alignItems:'center'}}>
        <RolePills />
      </div>

      <div className="flex gap-4 wrap" style={{marginTop:30, alignItems:'center'}}>
        <Stamp num="9,56" label="Avaliação / 10" tilt="l" />
        <Stamp num="4+" label="Anos de experiência" tilt="r" />
        <div className="grow" />
        <Ctas primary="Ver Projetos ↓" secondary="Baixar CV ↗" onPrimary={() => onNav?.("projetos")} />
      </div>

      <Anno top={62} right={10}>
        <b>Lottie no tamanho do H1 da variação A.</b><br/>
        Loop infinito · sem JS pesado.
      </Anno>
      <Anno bottom={-40} left={20}>
        <b>Selos rotacionados</b> ao invés de card de stats.<br/>
        Mais memorável + leve.
      </Anno>
    </section>

    {/* DESTAQUES — formato editorial (variação C) */}
    <section className="section">
      <SectionHdr idx="01" label="Destaques" right="2 projetos · rows alternadas · só os essenciais" />
      <div className="col" style={{gap:'var(--gap-5)'}}>
        {[
          { t:"MobiStudio",  tags:["Autoral","JS · Canvas","Builder.io"] },
          { t:"Rap In Cena", tags:["Festival","Identidade","Audiovisual"] },
        ].map((p, i) => (
          <div className="grid-2" key={p.t} style={{alignItems:'center'}}>
            {i % 2 === 0 ? (
              <>
                <Box kind="solid" ar="ar-16-9" withX label={`Banner ${p.t}`} sub="lazy · WebP · aspect-ratio fixo" />
                <div className="col">
                  <span className="hl lg">{p.t}</span>
                  <div className="pill-row">{p.tags.map(x => <span key={x} className="pill">{x}</span>)}</div>
                  <Lines widths={["w-95","w-90","w-70"]} />
                  <span className="mono">Ver case →</span>
                </div>
              </>
            ) : (
              <>
                <div className="col">
                  <span className="hl lg">{p.t}</span>
                  <div className="pill-row">{p.tags.map(x => <span key={x} className="pill">{x}</span>)}</div>
                  <Lines widths={["w-95","w-90","w-70"]} />
                  <span className="mono">Ver case →</span>
                </div>
                <Box kind="solid" ar="ar-16-9" withX label={`Banner ${p.t}`} sub="lazy · WebP · aspect-ratio fixo" />
              </>
            )}
          </div>
        ))}
      </div>
    </section>

    {/* STACK / MARQUEE */}
    <section className="section">
      <SectionHdr idx="02" label="Stack" right="CSS marquee infinito · pause on hover" />
      <Marquee size="default" />
    </section>

    {/* RECOMENDAÇÃO — pull-quote único */}
    <section className="section">
      <SectionHdr idx="03" label="Recomendação" right="só uma · acervo completo em /sobre" />
      <div className="card lift" style={{padding:'28px 32px'}}>
        <span style={{fontFamily:'var(--hand-display)', fontSize:64, lineHeight:0.6, color:'var(--ink-soft)'}}>"</span>
        <p className="hl md" style={{maxWidth:780, marginTop:6}}>
          Pull-quote curto e direto. Uma frase forte de liderança, ocupando todo o espaço como manifesto.
        </p>
        <div className="flex gap-2 aic" style={{marginTop:14, justifyContent:'space-between'}}>
          <div className="flex gap-2 aic">
            <Box kind="solid" ar="ar-1-1" style={{width:44, height:44, minHeight:0, padding:0}} />
            <div>
              <div style={{fontFamily:'var(--hand-display)', fontWeight:700, fontSize:18}}>Nome Lider</div>
              <div className="mono muted">Cargo · Empresa</div>
            </div>
          </div>
          <a className="mono" onClick={() => onNav?.("sobre")} style={{cursor:'pointer'}}>
            Ver todas as recomendações →
          </a>
        </div>
      </div>
    </section>

    <Footer />
  </>
);

window.HomeFinal = HomeFinal;
