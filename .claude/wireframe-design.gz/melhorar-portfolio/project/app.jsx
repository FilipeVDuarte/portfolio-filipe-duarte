// app.jsx — router + Tweaks (consolidado: 1 Home)

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "page": "home",
  "annotations": true,
  "density": "regular",
  "showFrame": true
}/*EDITMODE-END*/;

const PAGES = [
  { id: "home",     label: "Home",     url: "" },
  { id: "projetos", label: "Projetos", url: "projetos" },
  { id: "case",     label: "Case",     url: "projetos/nome-do-case" },
  { id: "sobre",    label: "Sobre",    url: "sobre" },
];

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const page = t.page;

  React.useEffect(() => {
    document.body.dataset.anno = t.annotations ? "on" : "off";
    document.body.dataset.density = t.density;
  }, [t.annotations, t.density]);

  React.useEffect(() => {
    if (window.location.hash !== `#${page}`) {
      history.replaceState(null, "", `#${page}`);
    }
  }, [page]);

  const onNav = (id) => setTweak("page", id);

  const renderPage = () => {
    if (page === "projetos") return <ProjetosPage onNav={onNav} />;
    if (page === "case")     return <CasePage onNav={onNav} />;
    if (page === "sobre")    return <SobrePage onNav={onNav} />;
    return <HomeFinal onNav={onNav} />;
  };

  const currentPage = PAGES.find(p => p.id === page) || PAGES[0];

  return (
    <div className="app">
      <header className="app__hdr">
        <div>
          <h1>Refatoração de portfólio · wireframes</h1>
          <small>Hub & spoke · 4 páginas · versão consolidada · low-fi</small>
        </div>
        <div className="app__route">
          rota: <b>/{currentPage.url || "—"}</b><br/>
          <span className="muted">página {PAGES.findIndex(p => p.id === page) + 1} de {PAGES.length}</span>
        </div>
      </header>

      <div className="tabs-row">
        <div className="tabs">
          {PAGES.map(p => (
            <button key={p.id}
              className="tabs__btn"
              aria-current={page === p.id}
              onClick={() => setTweak("page", p.id)}
            >
              {p.label}
            </button>
          ))}
        </div>
        <span className="mono muted">Clique nas tabs ou na nav do wireframe ↓</span>
      </div>

      {t.showFrame ? (
        <Frame url={currentPage.url}>{renderPage()}</Frame>
      ) : (
        <div className="page" style={{position:'relative'}}>{renderPage()}</div>
      )}

      <TweaksPanel title="Tweaks">
        <TweakSection label="Navegação" />
        <TweakSelect
          label="Página"
          value={t.page}
          options={PAGES.map(p => ({ value: p.id, label: p.label }))}
          onChange={(v) => setTweak("page", v)}
        />

        <TweakSection label="Exibição" />
        <TweakToggle
          label="Anotações de design"
          value={t.annotations}
          onChange={(v) => setTweak("annotations", v)}
        />
        <TweakToggle
          label="Browser frame"
          value={t.showFrame}
          onChange={(v) => setTweak("showFrame", v)}
        />
        <TweakRadio
          label="Densidade"
          value={t.density}
          options={["compact","regular","comfy"]}
          onChange={(v) => setTweak("density", v)}
        />

        <TweakSection label="Atalhos" />
        <TweakButton
          label="↻ Resetar"
          onClick={() => setTweak({ page: "home", annotations: true, density: "regular", showFrame: true })}
        />
        <TweakButton
          label="Preview limpo (sem anotações)"
          secondary={true}
          onClick={() => setTweak({ annotations: false })}
        />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
