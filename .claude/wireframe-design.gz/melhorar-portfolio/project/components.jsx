// components.jsx — shared wireframe primitives (Nav, Footer, Box, Annotation)

const Nav = ({ active = "home", onNav }) => (
  <nav className="wf-nav">
    <a className="wf-nav__logo" onClick={() => onNav?.("home")} style={{cursor:'pointer'}}>
      <span className="badge">FD</span>
      Filipe Duarte
    </a>
    <div className="wf-nav__links">
      <a className={active === "home" ? "active" : ""} onClick={() => onNav?.("home")}>Home</a>
      <a className={active === "projetos" ? "active" : ""} onClick={() => onNav?.("projetos")}>Projetos</a>
      <a className={active === "sobre" ? "active" : ""} onClick={() => onNav?.("sobre")}>Sobre</a>
    </div>
    <div className="wf-nav__tools">
      <span title="Idioma">EN</span>
      <span title="Tema">◐</span>
    </div>
  </nav>
);

const Footer = () => (
  <footer className="wf-footer">
    <div className="contacts">
      <b>Vamos conversar.</b>
      <span>filipe@email.com</span>
      <span>+55 51 9 0000 0000  ·  WhatsApp</span>
    </div>
    <div style={{display:'flex', flexDirection:'column', gap:8, alignItems:'flex-end'}}>
      <div className="mono-list mono">
        <span>LinkedIn ↗</span>
        <span>Behance ↗</span>
        <span>GitHub ↗</span>
      </div>
      <div className="mono muted">© 2026 · Filipe V. Duarte Delfino</div>
    </div>
  </footer>
);

// Sketchy placeholder box
const Box = ({ label, sub, kind = "", ar = "", withX = false, style, children, className = "" }) => {
  const cls = ["box", kind, ar, withX ? "with-x" : "", className].filter(Boolean).join(" ");
  return (
    <div className={cls} style={style}>
      {label ? <div className="label">{label}{sub ? <span className="sub">{sub}</span> : null}</div> : children}
    </div>
  );
};

// Faux text block (fake paragraph)
const Lines = ({ widths = ["w-95","w-90","w-80","w-60"] }) => (
  <div className="lines">
    {widths.map((w, i) => <i key={i} className={w} />)}
  </div>
);

// Section header
const SectionHdr = ({ idx, label, right, h = "lg" }) => (
  <div className="section__hdr">
    <div>
      <span className="eyebrow">{idx} — {label}</span>
      {right === undefined ? null : null}
    </div>
    {right ? <div className="mono muted">{right}</div> : null}
  </div>
);

// Annotation bubble (toggleable via body[data-anno])
// position: {top, left, right, bottom} in px relative to nearest positioned ancestor (use .frame__body or .page)
const Anno = ({ children, top, left, right, bottom, arrow }) => (
  <div className="anno" style={{ top, left, right, bottom }}>
    {arrow ? <ArrowSvg {...arrow} /> : null}
    {children}
  </div>
);

const ArrowSvg = ({ dir = "down-left", w = 60, h = 40, top = 0, left = 0, right, bottom }) => {
  const path = (() => {
    switch (dir) {
      case "down-left":  return "M2,2 Q30,10 30,28 L30,32 M22,26 L30,34 L38,26";
      case "down-right": return `M${w-2},2 Q${w-30},10 ${w-30},28 L${w-30},32 M${w-38},26 L${w-30},34 L${w-22},26`;
      case "up-left":    return `M2,${h-2} Q30,${h-12} 30,4 M22,12 L30,2 L38,12`;
      case "up-right":   return `M${w-2},${h-2} Q${w-30},${h-12} ${w-30},4 M${w-38},12 L${w-30},2 L${w-22},12`;
      case "right":      return `M2,${h/2} L${w-8},${h/2} M${w-14},${h/2-6} L${w-2},${h/2} L${w-14},${h/2+6}`;
      case "left":       return `M${w-2},${h/2} L8,${h/2} M14,${h/2-6} L2,${h/2} L14,${h/2+6}`;
      default:           return "";
    }
  })();
  return (
    <svg width={w} height={h} style={{ top, left, right, bottom, position: "absolute" }}>
      <path d={path} stroke="#1f6feb" strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

// Sketchy stamp (badge) for things like 9,56/10
const Stamp = ({ num, label, tilt = "l" }) => (
  <div className={`stamp ${tilt === "r" ? "tilt-r" : ""}`}>
    <div>
      <div className="num">{num}</div>
      <span className="meta">{label}</span>
    </div>
  </div>
);

// Pills for roles (UX/UI, Web Designer, etc)
const RolePills = ({ items = ["UX/UI", "Web Designer", "3D / Motion", "Dev Front", "IA Generativa"] }) => (
  <div className="pill-row">
    {items.map((t, i) => {
      const fills = ["fill-y", "fill-t", "fill-p", "fill-v", ""];
      return <span key={i} className={`pill ${fills[i % fills.length]}`}>{t}</span>;
    })}
  </div>
);

// Marquee with tool logos
const Marquee = ({ size = "default" }) => {
  const tools = [
    { name: "Figma",    glyph: "F" },
    { name: "Photoshop",glyph: "Ps" },
    { name: "Illustrator", glyph: "Ai" },
    { name: "Premiere", glyph: "Pr" },
    { name: "After Effects", glyph: "Ae" },
    { name: "Blender",  glyph: "B" },
    { name: "JavaScript", glyph: "JS" },
    { name: "HTML/CSS", glyph: "</>" },
    { name: "Claude",   glyph: "✦" },
    { name: "Builder.io", glyph: "B." },
  ];
  const cls = `marquee ${size === "compact" ? "compact" : size === "big" ? "big" : ""}`;
  return (
    <div className={cls}>
      <div className="marquee__track">
        {[...tools, ...tools].map((t, i) => (
          <div className="marquee__item" key={i}>
            <span className="logo">{t.glyph}</span>
            <span>{t.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// CTA buttons row
const Ctas = ({ primary = "Ver Projetos ↓", secondary = "Baixar CV (PDF) ↗", onPrimary, onSecondary }) => (
  <div className="flex gap-2 wrap">
    <button className="wf-btn primary" onClick={onPrimary}>{primary}</button>
    <button className="wf-btn" onClick={onSecondary}>{secondary}</button>
  </div>
);

// Frame for a "browser page"
const Frame = ({ url, children }) => (
  <div className="frame">
    <div className="frame__bar">
      <span className="dot" /><span className="dot" /><span className="dot" />
      <span className="url">filipeduarte.netlify.app/{url || ""}</span>
      <span className="muted">WIREFRAME</span>
    </div>
    <div className="frame__body">
      <div className="page" style={{ position: "relative" }}>
        {children}
      </div>
    </div>
  </div>
);

const PageSummary = ({ children }) => (
  <div className="page-summary">
    <b>Intenção</b>
    <span>{children}</span>
  </div>
);

Object.assign(window, {
  Nav, Footer, Box, Lines, SectionHdr, Anno, ArrowSvg,
  Stamp, RolePills, Marquee, Ctas, Frame, PageSummary
});
